function urlLoadFunction()
{
    // Return the document URL
    window.webkit.messageHandlers.locationURL.postMessage(location.href);
}

// Call the urlLoadFunction when the whole page has loaded
window.addEventListener('load', urlLoadFunction);

// Callback function to execute when mutations are observed
const urlCallback = function(mutationsList, observer)
{
    urlLoadFunction();
};

// Create an observer instance linked to the callback function
const urlObserver = new MutationObserver(urlCallback);

// Start observing the target node for configured mutations
urlObserver.observe(document, { childList: true, subtree: true });
