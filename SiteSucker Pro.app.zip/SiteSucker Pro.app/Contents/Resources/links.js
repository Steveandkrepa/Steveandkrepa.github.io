var links = [];
function aRect(element) {
    var rect = element.getBoundingClientRect();
    var top = rect.top;
    var left = rect.left;
    var right = rect.right;
    var bottom = rect.bottom;
    for (let i = 0; i < element.children.length; i++) {
        var childRect = element.children[i].getBoundingClientRect();
        if (right - left > 0 && bottom - top > 0) {
            if (childRect.right - childRect.left > 0 && childRect.bottom - childRect.top > 0) {
                if (childRect.top < top) {
                    top = childRect.top;
                }
                if (childRect.left < left) {
                    left = childRect.left;
                }
                if (childRect.right > right) {
                    right = childRect.right;
                }
                if (childRect.bottom > bottom) {
                    bottom = childRect.bottom;
                }
            }
        }
        else if (childRect.right - childRect.left > 0 && childRect.bottom - childRect.top > 0) {
            var top = childRect.top;
            var left = childRect.left;
            var right = childRect.right;
            var bottom = childRect.bottom;
        }
    }
    rect = new DOMRect(left,
                       top,
                       right - left,
                       bottom - top);
    return rect;
}
function areaRect(element) {
    var rect = null;
    var imgRect = null;
    var parent = element.parentElement;
    if (parent.nodeName == 'MAP') {
        var mapName = parent.name;
    }
    var imgs = document.images;
    for (let j = 0; j < imgs.length; j++) {
        if (imgs[j].useMap == '#' + mapName) {
            imgRect = imgs[j].getBoundingClientRect();
            break;
        }
    }
    if (imgRect != null) {
        var shape = element.shape.toLowerCase();
        if (shape == 'default') {
            rect = imgRect;
        }
        else {
            var coords = element.coords.split(",");
            for (let j = 0; j < coords.length; j++) {
                coords[j] = parseFloat(coords[j]);
            }
            if (shape == 'rect') {
                rect = new DOMRect(imgRect.left + coords[0],
                                   imgRect.top + coords[1],
                                   coords[2] - coords[0],
                                   coords[3] - coords[1]);
            }
            else if (shape == 'circle') {
                rect = new DOMRect(imgRect.left + coords[0] - coords[2],
                                   imgRect.top + coords[1] - coords[2],
                                   2 * coords[2],
                                   2 * coords[2]);
            }
            else if (shape == 'poly') {
                var x1 = imgRect.width;
                var y1 = imgRect.height;
                var x2 = 0;
                var y2 = 0;
                for (let j = 0; j < coords.length; j+=2) {
                    if (coords[j] < x1) {
                        x1 = coords[j];
                    }
                    if (coords[j] > x2) {
                        x2 = coords[j];
                    }
                }
                for (let j = 1; j < coords.length; j+=2) {
                    if (coords[j] < y1) {
                        y1 = coords[j];
                    }
                    if (coords[j] > y2) {
                        y2 = coords[j];
                    }
                }
                rect = new DOMRect(imgRect.left + x1,
                                   imgRect.top + y1,
                                   x2 - x1, y2 - y1);
            }
        }
    }
    return rect;
}
function addToLinks(element, rect) {
    var link = [];
    var rel = "";
    var id = "";
    var name = "";
    var href = "";
    if (element.getAttribute("rel")) {
        rel = element.getAttribute("rel");
    }
    if (element.getAttribute("id")) {
        id = element.getAttribute("id");
    }
    if (element.getAttribute("name")) {
        name = element.getAttribute("name");
    }
    if (element.getAttribute("href")) {
        href = element.href;
    }
    if (id != "" || name != "" || href != "") {
        link.push(String(rect.left));
        link.push(String(rect.top));
        link.push(String(rect.width));
        link.push(String(rect.height));
        link.push(rel);
        link.push(id);
        link.push(name);
        link.push(href);
        links.push(link);
    }
}
var robots = "";
var elements = document.getElementsByTagName("META");
for (let i = 0; i < elements.length; i++) {
    var name = elements[i].getAttribute("name");
    if (name && name.toLowerCase() == "robots") {
        robots = elements[i].getAttribute("content");
        break;
    }
}
links.push(robots);
elements = document.body.getElementsByTagName("*");
for (let i = 0; i < elements.length; i++) {
    var element = elements[i];
    var rect = null;
    if (element.nodeName == 'A') {
        rect = aRect(element);
    }
    else if (element.nodeName == 'AREA') {
        rect = areaRect(element);
    }
    else {
        rect = element.getBoundingClientRect();
    }
    if (rect != null)  {
        if (rect.width != 0 && rect.height != 0) {
            addToLinks(element, rect);
        }
    }
}
links;
