var forms = document.forms;
var i, j;
for (j = 0; j < forms.length; j++) {
    var form = forms[j];
    var accountInput = null;
    var passwordInput = null;
    for (i = 0; i < form.length; i++) {
        var element = form.elements[i];
        if (element.tagName == "INPUT") {
            if (element.getAttribute("type") == "text") {
                accountInput = element;
            }
            else if (element.getAttribute("type") == "userid") {
                accountInput = element;
            }
            else if (element.getAttribute("type") == "email") {
                accountInput = element;
            }
            else if (element.getAttribute("type") == "password") {
                passwordInput = element;
            }
        }
    }
    if (accountInput != null && passwordInput != null) {
        accountInput.focus();
        accountInput.value = "%@";
        passwordInput.focus();
        passwordInput.value = "%@";
        passwordInput.blur();
        break;
    }
}
