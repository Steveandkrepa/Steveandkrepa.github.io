var forms = document.forms;
var i, j;
for (j = 0; j < forms.length; j++) {
    var form = forms[j];
    var accountInput = null;
    var passwordInput = null;
    var submitInput = null;
    for (i = 0; i < form.length; i++) {
        var element = form.elements[i];
        if (element.tagName == "INPUT") {
            if (element.getAttribute("type") == "text") {
                accountInput = element;
            }
            else if (element.getAttribute("type") == "userid") {
                accountInput = element;
            }
            else if (element.getAttribute("type") == "email") {
                accountInput = element;
            }
            else if (element.getAttribute("type") == "password") {
                passwordInput = element;
            }
            else if (element.getAttribute("type") == "submit") {
                submitInput = element;
            }
        }
    }
    if (accountInput != null && passwordInput != null && submitInput != null) {
        submitInput.accountInput = accountInput;
        submitInput.passwordInput = passwordInput;
        submitInput.addEventListener('click', clickSubmit, false);
        window.webkit.messageHandlers.foundLogin.postMessage('');
    }
}
function clickSubmit(evt)
{
    var message = {
    account: evt.target.accountInput.value,
    password: evt.target.passwordInput.value,
    URL: document.URL
    };
    window.webkit.messageHandlers.userLogin.postMessage(message);
}
