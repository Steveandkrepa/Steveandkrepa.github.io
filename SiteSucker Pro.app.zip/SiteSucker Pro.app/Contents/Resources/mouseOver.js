function mouseOver()
{
    window.webkit.messageHandlers.sendLink.postMessage(event.currentTarget.href);
}

function mouseOut()
{
    window.webkit.messageHandlers.sendLink.postMessage('');
}

function mouseLoadFunction()
{
    var allLinks = document.links;
    for (var i = 0; i < allLinks.length; i++)
    {
        allLinks[i].addEventListener('mouseover', mouseOver);
        allLinks[i].addEventListener('mouseout', mouseOut);
    }
}

// Call the mouseLoadFunction when the whole page has loaded
window.addEventListener('load', mouseLoadFunction);

// Callback function to execute when mutations are observed
const mouseCallback = function(mutationsList, observer)
{
    mouseLoadFunction();
};

// Create an observer instance linked to the callback function
const mouseObserver = new MutationObserver(mouseCallback);

// Start observing the target node for configured mutations
mouseObserver.observe(document, { childList: true, subtree: true });
